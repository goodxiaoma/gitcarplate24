# car2024
项目汇总
## OPENMV
### openmvuart端口  
将openmv与CH573进行数据传输  
openmv使用uart3端口： TX-PB10 ;RX-PB11  
CH543使用uart0端口：  TX-PB7 ;RX-PB4  
如图示例车牌图  
<div align=center>
<img src="https://github.com/goodxiaoma/car2024/blob/main/%E7%A4%BA%E4%BE%8B%E8%BD%A6%E7%89%8C%E5%9B%BE/%E4%BA%AC.png" width="200"> 
</div>
